## uk

Для ініціалізації проєкта потрібно виконати в консолі команду:

## npm i

Для запуску коду використовуємо в консолі скрипт:

## run start:dev

Додаток Todo працює по таких маршрутах:

## get /api/todo;

## get /api/todo/id;

## post /api/todo/;

## put /api/todo/id;

та приймає в body обов'язкові параметри  
{"name":"string","complited":"bollean"}

## delete /api/todo/id

---

## en

To initialize the project, execute the following command in the console:

## npm i

To run the code, use the script in the console:

## run start:dev

The Todo app works on the following routes:

## get /api/todo;

## get /api/todo/id;

## post /api/todo/;

## put /api/todo/id;

and the user in body required parameters

{"name":"string","completed":"bollean"}

## delete /api/todo/id
