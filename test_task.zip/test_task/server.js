import app from './app.js';

app.listen(3000, () => console.log('Server runing at 3000 port'));
